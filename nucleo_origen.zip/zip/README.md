[![Scrutinizer Code Quality](https://github.com/dvegas1/facturacion_gtakounting)](https://github.com/dvegas1/facturacion_gtakounting)

# Facturacion
*Software de facturación y contabilidad para pymes, fácil, libre y con actualizaciones constantes. Es compatible con FacturaLux, Abanq y Eneboo. Es software libre bajo licencia GNU/LGPL.*

## Instalación
Para instalarlo sólo necesitas PHP 5.4 o superior, PostgreSQL o MySQL. Puedes ver documentación más detallada en la documentación:


## Feedback
Para cualquier duda, problema o sugerencia:


## Colaborar
Si desdeas colaborar puedes dirigirte a la sección en nuestra web con todas las tareas pendientes, documentación y chat para programadores:

